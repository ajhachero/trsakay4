<?php
include('../php/session_commuter.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TriSakay | Commuter</title>
    <?php
    $imagePath = "../img/Logo_Nobg.png";
    ?>
    <link rel="icon" href="<?php echo $imagePath; ?>" type="image/png" />
    <?php
    include '../dependencies/dependencies.php';
    ?>
    <link rel="stylesheet" href="../css/history.css">
    

</head>

<body>
    
    <?php
    include('../php/navbar_commuter.php');
    ?>
   

    <?php

    include('../db/dbconn.php');
  
    $commuterId = $_SESSION["commuterid"];
    $query = "SELECT firstname FROM commuter WHERE commuterid = ?";
    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
      mysqli_stmt_bind_param($stmt, "s", $commuterId);
      mysqli_stmt_execute($stmt);

      $result = mysqli_stmt_get_result($stmt);

      if ($result) {
        if (mysqli_num_rows($result) > 0) {
          $row = mysqli_fetch_assoc($result);
          $firstname = $row['firstname'];
          echo "<h5>We hope you enjoy your next ride with <strong>TriSakay</strong>, $firstname.</h5>";
        } else {
          echo "<h5>User not found.</h5>";
        }
      } else {
        echo "<h5>Error querying the database.</h5>";
      }

      mysqli_stmt_close($stmt);
    } else {
      echo "<h5>Error preparing the statement.</h5>";
    }

    mysqli_close($conn);
    ?>

<section class="container section section__height" id="history">
        <h2 class="section__title">History</h2>
        <table class="history-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Driver Name</th>
                    <th>Body #</th>
                    <th>Status</th>
                    <th>Route</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>2023-11-01</td>
                    <td>Apol</td>
                    <td>12345</td>
                    <td>Completed</td>
                    <td>Baliwag</td>
                </tr>
                <tr>
                    <td>2023-11-02</td>
                    <td>Jonathan Mariano</td>
                    <td>67890</td>
                    <td>Canceled</td>
                    <td>San Rafael</td>
                </tr>
                <!-- Add more rows as needed -->
            </tbody>
        </table>
    </section>


    <script src="../js/button.js"></script>
</body>

</html>