<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/manage.css">
    <title>Profile Settings</title>
</head>
<body>
    <button id="back-button" style="position: absolute; top: 10px; left: 10px; background-color: #407c87; width: 125px; height: 50px; font-size: 12;">Back</button>
    <h1>Profile Settings</h1>
    <div class="profile-pic">
        <img id="profile-image" onclick="document.getElementById('image-upload').click()" src="https://scontent.fmnl8-2.fna.fbcdn.net/v/t1.15752-9/368597689_660127999585867_1478620372354619223_n.png?_nc_cat=109&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFTEiNo7Rrt4V3f2RDkaLpT_hwoa7nvHdz-HChrue8d3AHJ_RuE_iphRj6UMLgT1ZUt0cp27j-hU1GE313ekn4E&_nc_ohc=TfG1h9QQyKwAX9hyBQq&_nc_ht=scontent.fmnl8-2.fna&oh=03_AdTQ5Tn8y3U6cetY0Ylt8KCJEQbK5qgxz-gUS53_s-JVYQ&oe=65712427" alt="Profile Picture">
        <input type="file" id="image-upload" accept="image/*" onchange="previewImage()">
    </div>
    <button id="change-password-button" style="background-color: #407c87; width: 100px; height: 50px; font-size: 12;">Change Password</button>
    <div id="password-modal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h2>Change Password</h2>
            <form id="password-form">
                <label for="current-password">Current Password:</label>
                <input type="password" id="current-password" required>
                <label for="new-password">New Password:</label>
                <div class="password-input">
                    <input type="password" id="new-password" required>
                    <span class="show-password" onclick="togglePasswordVisibility('new-password')">&#x1F441;</span>
                </div>
                <label for="confirm-password">Confirm New Password:</label>
                <div class="password-input">
                    <input type="password" id="confirm-password" required>
                    <span class="show-password" onclick="togglePasswordVisibility('confirm-password')">&#x1F441;</span>
                </div>
                <button type="submit" style="background-color:#407c87;">Save</button>
            </form>
        </div>
    </div>

    <script>
        // Set the initial password field visibility to "password"
        document.getElementById('new-password').type = 'password';
        document.getElementById('confirm-password').type = 'password';

        // Function to open the modal
        function openModal() {
            document.getElementById('password-modal').style.display = 'block';
        }

        // Function to close the modal
        function closeModal() {
            document.getElementById('password-modal').style.display = 'none';
        }

        // Function to toggle password visibility
        function togglePasswordVisibility(passwordFieldId) {
            var passwordInput = document.getElementById(passwordFieldId);
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }

        // Add event listener to change password button to toggle modal
        document.getElementById('change-password-button').addEventListener('click', function () {
            var modal = document.getElementById('password-modal');
            if (modal.style.display === 'block') {
                closeModal(); // Close the modal if it's open
            } else {
                openModal(); // Open the modal if it's closed
            }
        });

        // Function to preview image once a new image file is selected
        function previewImage() {
            var oFReader = new FileReader();
            oFReader.readAsDataURL(document.getElementById("image-upload").files[0]);

            oFReader.onload = function (oFREvent) {
                document.getElementById("profile-image").src = oFREvent.target.result;
            };
        }

        // Add functionality to the Back button
        document.getElementById('back-button').addEventListener('click', function () {
    window.location.href='commuter.php'
        });
    </script>
</body>
</html>
