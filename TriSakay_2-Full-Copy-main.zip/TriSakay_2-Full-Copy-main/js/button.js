function redirectToScan() {
  window.location.href = "../drop/test4.php";
}
function redirectToScan() {
  window.location.href = "../drop/test4.php";
}
function redirectToMyLocation() {
  window.location.href = "../commuter/mylocation.php";
}
function redirectToCommuter() {
  window.location.href = "../commuter/commuter.php";
}
function redirectToContacts() {
  window.location.href = "../commuter/contacts.php";
}
function redirectToChangePass() {
  window.location.href = "../commuter/changepass.php";
}
function redirectToBookings() {
  window.location.href = "../drop/test2.php";
}
function redirectToManage() {
  window.location.href = "../commuter/manage.php";
}
function redirectToGuest() {
  window.location.href = "../guest/guest.php";
}
function redirectToMyLocationGuest() {
  window.location.href = "../guest/done.php";
}
function redirectToScanGuest() {
  window.location.href = "../guest/scan.php";
}
function redirectToShape() {
  window.location.href = "../shape/drawing.php";
}
function redirectToPending() {
  window.location.href = "../dispatcher/pending.php";
}
